# 堆叠任务布局（Stacked Recents）— LSPosed 模块

把 ColorOS 的最近任务卡片改成**堆叠**样式：卡片之间负间距、互相叠起来，当前卡片置顶，滑动切换。

最小实现，只 hook 两个点：

| Hook 点 | 作用 |
| --- | --- |
| `com.android.launcher3.DeviceProfile` 构造 → `overviewPageSpacing` | 页面间距设为 `-(level*10)dp` |
| `com.android.quickstep.views.RecentsView.setPageSpacing(int)` | 老分支的等价入口 |
| `RecentsView.notifyPageSwitchListener` / `resetTaskVisuals` | 当前卡片 `z=999`，不被压住 |

## 编译（不用装 Android SDK）

1. 把这个目录推到你的 GitHub 仓库（公开/私有都行）；
2. 仓库 Actions 会自动跑 `.github/workflows/build.yml`；
3. 跑完在 **Actions → 最新一次 run → Artifacts** 下载 `stacked-recents-debug`，里面就是 APK。

本地编译也行：Android Studio 打开本目录直接 Build，或 `gradle assembleDebug`（需要 JDK 17 + Android SDK 34）。

## 安装

1. 安装 APK（debug 签名，可直装）；
2. LSPosed 管理器 → 模块 → 启用「堆叠任务布局」；
3. 作用域勾选 **系统桌面**（`com.android.launcher`，你机器上就是它；`com.android.launcher3` / `com.oppo.launcher` 也列了，按实际装的那个勾）；
4. 重启手机（或强制停止系统桌面）。

## 调堆叠层数

层数从系统属性读，默认 7（范围被限制在 1~10）：

```sh
su -c 'setprop persist.sys.stacked_recents.level 5'
```

然后强制停止桌面让它重新加载：

```sh
su -c 'am force-stop com.android.launcher'
```

数值越大叠得越狠（每级 10dp）。建议 5~8，太大容易互相遮挡、滑动误触。

## 排错

看 LSPosed 日志（过滤器输 `StackedRecents`）：

```sh
su -c 'logcat -d -s LSPosed-Bridge:I | grep StackedRecents'
```

- 只有 `loaded in ...` 没有 `DeviceProfile hooked` → 类名不对，说明你这版 launcher 的 `DeviceProfile` 不在 `com.android.launcher3` 下，把 logcat 里 `ClassNotFound` 那行发我；
- `DeviceProfile hooked` 有、但卡片没叠 → 说明间距不是这里算的，需要再 hook `RecentsView` 的布局方法（把日志发我，我按你机器的类结构补）。

## 许可证

MIT。代码思路参考 LuckyTool（`com.luckyzyx.luckytool.hook.scopes.launcher.StackedTaskLayout`），这里用标准 Xposed API 重写，不依赖 YukiHookAPI。
