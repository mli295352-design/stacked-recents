package io.github.dsh.stackedrecents;

import android.content.res.Resources;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

/**
 * 最近任务卡片堆叠（最小实现）
 *
 * 原理与 LuckyTool 的 StackedTaskLayout 相同：
 *   1. DeviceProfile.overviewPageSpacing = -(level * 10)dp  → 卡片互相叠起来
 *   2. RecentsView.setPageSpacing(...) 同样给负值（老版本走这里）
 *   3. 当前卡片 z 值抬高，避免被下面的卡片压住
 *
 * 层数通过系统属性 persist.sys.stacked_recents.level 调整（默认 7，范围建议 5~10）：
 *   su -c 'setprop persist.sys.stacked_recents.level 6'
 * 改完强制停止桌面（或重启）生效。
 */
public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "[StackedRecents] ";
    private static final String[] SCOPE = {
            "com.android.launcher",
            "com.android.launcher3",
            "com.oppo.launcher"
    };
    private static final String PROP_LEVEL = "persist.sys.stacked_recents.level";
    private static final int DEFAULT_LEVEL = 7;

    @Override
    public void handleLoadPackage(LoadPackageParam lpparam) {
        boolean inScope = false;
        for (String p : SCOPE) {
            if (p.equals(lpparam.packageName)) {
                inScope = true;
                break;
            }
        }
        if (!inScope) return;

        int level = DEFAULT_LEVEL;
        try {
            level = Integer.parseInt(getProp(PROP_LEVEL, String.valueOf(DEFAULT_LEVEL)).trim());
        } catch (Throwable ignored) {
        }
        if (level < 1) level = 1;
        if (level > 10) level = 10;

        float density = 3f;
        try {
            density = Resources.getSystem().getDisplayMetrics().density;
        } catch (Throwable ignored) {
        }
        final int spacingPx = -(int) (level * 10 * density);

        XposedBridge.log(TAG + "loaded in " + lpparam.packageName
                + " level=" + level + " spacing=" + spacingPx + "px");

        hookDeviceProfile(lpparam.classLoader, spacingPx);
        hookRecentsView(lpparam.classLoader, spacingPx);
    }

    /** 新版本 Launcher3 在 DeviceProfile 里算页面间距 */
    private void hookDeviceProfile(ClassLoader cl, final int spacingPx) {
        try {
            Class<?> clazz = XposedHelpers.findClassIfExists("com.android.launcher3.DeviceProfile", cl);
            if (clazz == null) {
                XposedBridge.log(TAG + "DeviceProfile not found");
                return;
            }
            XposedBridge.hookAllConstructors(clazz, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        Field f = findField(param.thisObject.getClass(), "overviewPageSpacing");
                        if (f == null) return;
                        f.setAccessible(true);
                        f.setInt(param.thisObject, spacingPx);
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + "DeviceProfile hook: " + t);
                    }
                }
            });
            XposedBridge.log(TAG + "DeviceProfile hooked");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "DeviceProfile error: " + t);
        }
    }

    /** 老版本 / 部分分支通过 RecentsView.setPageSpacing 设置 */
    private void hookRecentsView(ClassLoader cl, final int spacingPx) {
        try {
            Class<?> clazz = XposedHelpers.findClassIfExists("com.android.quickstep.views.RecentsView", cl);
            if (clazz == null) {
                XposedBridge.log(TAG + "RecentsView not found");
                return;
            }

            Method setPageSpacing = XposedHelpers.findMethodExactIfExists(clazz, "setPageSpacing", int.class);
            if (setPageSpacing != null) {
                XposedBridge.hookMethod(setPageSpacing, new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) {
                        param.args[0] = spacingPx;
                    }
                });
                XposedBridge.log(TAG + "setPageSpacing hooked");
            }

            for (final String name : new String[]{"notifyPageSwitchListener", "resetTaskVisuals"}) {
                Method m = XposedHelpers.findMethodExactIfExists(clazz, name);
                if (m == null) continue;
                XposedBridge.hookMethod(m, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        raiseCurrentTask(param.thisObject);
                    }
                });
                XposedBridge.log(TAG + name + " hooked");
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "RecentsView error: " + t);
        }
    }

    /** 把当前选中卡片抬到最上层 */
    private void raiseCurrentTask(Object recentsView) {
        try {
            Method getCurrent = XposedHelpers.findMethodExactIfExists(
                    recentsView.getClass(), "getCurrentPageTaskView");
            if (getCurrent == null) return;
            Object view = getCurrent.invoke(recentsView);
            if (view == null) return;
            XposedHelpers.setFloatField(view, "z", 999f);
        } catch (Throwable t) {
            XposedBridge.log(TAG + "raiseCurrentTask: " + t);
        }
    }

    /** 反射读系统属性（android.os.SystemProperties 是隐藏 API，编译期不可直接引用） */
    private static String getProp(String key, String def) {
        try {
            Class<?> cls = Class.forName("android.os.SystemProperties");
            Method m = cls.getMethod("get", String.class, String.class);
            Object v = m.invoke(null, key, def);
            return v instanceof String ? (String) v : def;
        } catch (Throwable t) {
            return def;
        }
    }

    private static Field findField(Class<?> cls, String name) {
        Class<?> c = cls;
        while (c != null) {
            try {
                return c.getDeclaredField(name);
            } catch (NoSuchFieldException ignored) {
                c = c.getSuperclass();
            }
        }
        return null;
    }
}
