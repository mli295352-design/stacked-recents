plugins { id("com.android.application") }

android {
    namespace = "io.github.dsh.stackedrecents"
    compileSdk = 34

    defaultConfig {
        applicationId = "io.github.dsh.stackedrecents"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }
}

dependencies {
    // Xposed API 已内置在 app/libs，不再依赖 api.xposed.info 仓库
    compileOnly(files("libs/xposed-api-82.jar"))
}
